var nombre = "john";
var admin = nombre;;

    document.write( "El usuario es: " + nombre + "<br>" );
    document.write( "El administrador es: " + admin + "<br>" );